Kitti Sequence from "http://www.cvlibs.net/download.php?file=data_tracking_image_3.zip" :: /training/image_02/0009

Folders and corresponding actions ::

gt_text_files :: Contains the annotations of keypoints. (64 x 64)

images :: Contains the corresponding images with resized version. (64 x 64)

Mapping_bbox.txt - Contains the mapping between out label images and KITTI sequence above and the corresponding bounding box.


